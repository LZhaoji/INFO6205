package INFO6205.assignment5;

import java.util.EmptyStackException;

public class CircularQueue {
    int rear;
    int front;
    int maximum_size;
    int[] arr;

    public CircularQueue(int size){
        rear = 0;
        front = 0;
        maximum_size = size;
        arr = new int[size];
    }
    public int size(){return (rear+maximum_size-front)%maximum_size;}
    public boolean isFull(){return (rear+1)%maximum_size == front;}
    public boolean isEmpty(){return rear==front;}
    public void enqueue(int item){
        if (isFull()){
            System.out.println(rear+""+front);
            System.out.println("queue is full");
            return;
        }
        arr[rear] = item;
        rear = (rear + 1) % maximum_size;
    }
    public int dequeue(){
        if (isEmpty()){
            System.out.println("queue is empty");
        }
        int item = arr[front];
        front = (front + 1) % maximum_size;
        return item;
    }
    public void displayQueue(){
        if (isEmpty()){
            System.out.println("queue is empty");
            return;
        }
        for (int i = front;i<front+size();i++){
            System.out.printf("arr[%d]=%d\n",i%maximum_size,arr[i%maximum_size]);
        }
    }
    public int peek(){
        if (isEmpty()){
            throw new EmptyStackException();
        }
        return arr[front];
    }


    public static void main(String[] args) {
        int[] arr = new int[]{54, 18, 77, 24, 11, 27, 43, 38, 3, 9, 82, 10, 21, 8, 34, 19, 6};
        CircularQueue queue = new CircularQueue(arr.length);
        for (int i:arr){
            queue.enqueue(i);
        }
        queue.displayQueue();
        System.out.println("----------------------------");
        for (int i =7;i>=0;i--){
            queue.dequeue();
        }
        queue.displayQueue();
        System.out.println("----------------------------");
        for (int i =0;i<5;i++){
            queue.enqueue(arr[i]);
        }
        queue.displayQueue();
        System.out.println("----------------------------");
        while (!queue.isEmpty()){
            queue.dequeue();
        }
        queue.displayQueue();
    }
}
