package INFO6205.assignment5;

import java.util.*;

public class HuffmanTree {
    public int[] getFrequency(String s){
        Map<Character,Integer> freq_map = new HashMap<>();
        int i,j;
        Set<Character> chars = new HashSet<>();
        for (i=0;i<s.length();i++){
            char current = s.charAt(i);
            if (!freq_map.containsKey(current)){
                freq_map.put(current,1);
            }else{
                int count = freq_map.get(current)+1;
                freq_map.put(current,count);
            }
            chars.add(current);
        }
        int[] arr = new int[freq_map.size()];
        Object[] objects = chars.toArray();
        for (j=0;j< freq_map.size();j++){
            char current = (char) objects[j];
            int freq = freq_map.get(current);
            arr[j] = freq;
        }
        return arr;
    }
    public Object[] getElement(String s){
        int i;
        Set<Character> l = new HashSet<>();
        //char[] chars = new char[s.length()];
        for (i=0;i<s.length();i++){
            char current = s.charAt(i);
           l.add(current);
        }
        return l.toArray();
    }
    public static void main(String[] args) {
        String s = "Students want to transfer files with gmail";
        HuffmanTree ht = new HuffmanTree();
        int[] arr = ht.getFrequency(s);
        Object[] element = ht.getElement(s);
        PriorityQueue<HuffmanNode> pq = new PriorityQueue<>(arr.length,new myComparator());
        for (int i=0;i<arr.length;i++){
            HuffmanNode hn = new HuffmanNode();
            hn.freq = arr[i];
            hn.c = (char) element[i];
            hn.left = null;
            hn.right = null;
            pq.add(hn);
        }

        HuffmanNode root = null;
        while (pq.size() >1){
            HuffmanNode x1 = pq.peek();
            pq.poll();
            HuffmanNode x2 = pq.peek();
            if (x2 == null){
                root = x1;
                break;
            }
            pq.poll();
            HuffmanNode y = new HuffmanNode();
            y.freq = x1.freq+ x2.freq;
            y.left = x1;
            y.right = x2;
            y.c = '#';
            root = y;
            pq.add(y);
        }
        assert root != null;
        ht.printCode(root,"");
    }
    public void printCode(HuffmanNode root,String s){
        if (root.left == null && root.right==null){
            System.out.println(root.c+":"+s);
            return;
        }
        assert root.left != null;
        printCode(root.left,s+"0");
        printCode(root.right,s+"1");
    }

}

class HuffmanNode{
    int freq;
    char c;
    HuffmanNode left;
    HuffmanNode right;
}
class myComparator implements Comparator<HuffmanNode>{

    @Override
    public int compare(HuffmanNode o1, HuffmanNode o2) {
        return o1.freq - o2.freq;
    }
}
/*
l:0000
w:0001
r:0010
u:00110
g:00111
d:01000
m:01001
f:0101
s:0110
a:0111
i:1000
e:1001
n:1010
S:10110
o:101110
h:101111
t:110
 :111


 */
