package INFO6205.assignment5;

public class User implements Comparable<User>{
    private String name;
    private int id;
    private String birth;

    public User (String name, int id, String birth)
    { this.name = name; this.id = id; this.birth = birth; }

    @Override
    public boolean equals(Object other) {
        if (this == other) return true;
        if (other == null || (this.getClass() != other.getClass()))
        { return false; }
        User guest = (User) other;
        if ((this.id != guest.id)) return false;//
        if (this.name == null) return false;
        return (name.equals(guest.name)) && (birth.equals(guest.birth));
    }

    @Override
    public int hashCode() {
        int result = 0;
        result = 31*result + id;
        result = 31*result + (name !=null ? name.hashCode() : 0);
        result = 31*result + (birth !=null ? birth.hashCode() : 0);
        return result;
    }

    @Override
    public int compareTo(User o) {
        return this.id - o.id;
    }

    public static void main(String[] args) {
        User u1 = new User("HashCode",10086,"98/01/12");
        User u2 = new User("HashCode",10086,"98/01/12");
        User u3 = new User("HashCode2",10086,"98/01/12");
        User u4 = new User("HashCode",10086,"89/6/24");
        System.out.println(u1.hashCode()+" "+u2.hashCode());
        System.out.println(u1.equals(u2));
        System.out.println(u1.compareTo(u2));

        System.out.println(u1.hashCode()+" "+u3.hashCode());
        System.out.println(u1.equals(u3));
        System.out.println(u1.compareTo(u3));
        /*
        -1889731830 -1889731830
        true
        0
        -1889731830 -1981286546
        false
        0
         */
    }
}
