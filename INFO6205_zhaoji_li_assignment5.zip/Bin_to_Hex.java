package INFO6205.assignment5;

public class Bin_to_Hex {
    // bin to dec
    public int binaryToDecimal(long binary){
        int decimal = 0;
        int i = 0;
        while (binary > 0){
            decimal += Math.pow(2,i++)*(binary%10);
            binary /= 10;
        }
        return decimal;
    }
    // dec to hex
    public String decimalToHex(int decimal){
        StringBuilder hex = new StringBuilder();
        int remainder;
        char[] arr = {'A','B','C','D','E','F'};
        while (decimal != 0){
            remainder = decimal % 16;
            if (remainder >= 10){
                hex.insert(0, arr[remainder - 10]);
            }else {
                hex.append(remainder);
            }
            decimal = decimal/16;
        }
        return hex.toString();
    }

    public static void main(String[] args) {
        Bin_to_Hex bth = new Bin_to_Hex();
        long num = 1100001101;
        System.out.println("input binary number is : "+num);
        int btd = bth.binaryToDecimal(num);
        System.out.println("binary to decimal: " + btd);
        System.out.println("decimal to hex: "+bth.decimalToHex(btd));
    }

    /*
    input binary number is : 1100001101
    binary to decimal: 781
    decimal to hex: D03
     */
}
