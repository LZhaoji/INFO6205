package INFO6205.assignment5;

public class calculateHashCode {
    public static void main(String[] args) {
        String s = "Welcome Students";
        System.out.println(s.hashCode()); //-1157996330
        System.out.println("sm".hashCode());
    }
}
