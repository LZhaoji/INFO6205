package INFO6205.assignment23;


import java.util.*;

public class Postfix_And_Result {
    public Postfix_And_Result() {}
    static class ArrayStack {
        private int top = -1;
        private String[] objects;

        public ArrayStack(int capacity) {
            objects = new String[capacity];
        }
        public int size(){return top+1;}

        public boolean isEmpty() {
            return top == -1;
        }

        public boolean isFull() {
            return top == objects.length - 1;
        }

        public void push(String obj) {
            if (isFull()) {
                System.out.println("Stack is full");
                resize(2* objects.length);
            }
            objects[++top] = obj;
        }

        public String pop() {
            if (isEmpty()) {
                return "Stack is empty";
            }
            String value = objects[top];
            top--;
            return value;
        }

        public String peak() {
            if ( isEmpty()) {
                //return (T) arr[top];
                throw new EmptyStackException();
            }
            return objects[top];
        }

        public void resize(int capacity) {
            String[] copy = new String[capacity];
            for (int i = 0; i < top+1; i++)
                copy[i] = objects[i];
            objects = copy;
        }

    }
    //第八题答案
    public String In_Po_Re(String[] infix){
        int index = 0;
        double result;

        Map<String, Integer> Oper_Map = new HashMap<>();
        Oper_Map.put("+", 1);
        Oper_Map.put("-", 1);
        Oper_Map.put("*", 2);
        Oper_Map.put("/", 2);

        ArrayStack Operand_stack = new ArrayStack(infix.length);//数
        ArrayStack Operator_stack = new ArrayStack(infix.length);//符

        for (int i = 0; i < infix.length; i++) {
            String current = infix[i];

            if (!isOper(current) && !isBracket(current)) {//不是符号和括号,只有数字,就把数字添加到Operand_stack里面
                Operand_stack.push(current);
            }
            else if (isBracket(current)) {//是括号
                //是左括号
                if (current.equals("(")) {
                    Operator_stack.push(current);
                } else if (current.equals(")")) {//是右括号
                    switch (Operator_stack.peak()){// 把括号里面的符号弹出来
                        case "+" ->{
                            result = todouble(Operand_stack.pop()) + todouble(Operand_stack.pop());
                            Operand_stack.push(String.valueOf(result));
                        }
                        case "-" ->{
                            result = -(todouble(Operand_stack.pop()) - todouble(Operand_stack.pop()));
                            Operand_stack.push(String.valueOf(result));
                        }
                        case "*" ->{
                            result = todouble(Operand_stack.pop()) * todouble(Operand_stack.pop());
                            Operand_stack.push(String.valueOf(result));
                        }
                        case "/" ->{
                            result = 1 / (todouble(Operand_stack.pop()) / todouble(Operand_stack.pop()));
                            Operand_stack.push(String.valueOf(result));
                        }
                    }
                    Operator_stack.pop();//弹+-*/
                    Operator_stack.pop(); // 把左括号弹出来
                }
            }else if (isOper(current)){//是符
                if (Operator_stack.isEmpty()){//如果符号栈为空，就push一个符号进去
                    Operator_stack.push(current);
                }
                else if (isBracket(Operator_stack.peak())){//如果前面是左括号，也直接push进去
                    Operator_stack.push(current);
                }
                else if (Oper_Map.get(Operator_stack.peak()) >= Oper_Map.get(current) ){//栈里面已经有*/ 一定先运算*/，如果前面是+-，也要先算前面的操作符
                    switch (Operator_stack.peak()){
                        case "+" ->{
                            result = todouble(Operand_stack.pop()) + todouble(Operand_stack.pop());
                            Operand_stack.push(String.valueOf(result));
                        }
                        case "-" ->{
                            result = -(todouble(Operand_stack.pop()) - todouble(Operand_stack.pop()));
                            Operand_stack.push(String.valueOf(result));
                        }
                        case "*" ->{
                            result = todouble(Operand_stack.pop()) * todouble(Operand_stack.pop());
                            Operand_stack.push(String.valueOf(result));
                        }
                        case "/" ->{
                            result = 1 / (todouble(Operand_stack.pop()) / todouble(Operand_stack.pop()));
                            Operand_stack.push(String.valueOf(result));
                        }
                    }
                    Operator_stack.pop();
                    Operator_stack.push(current);
                }
                else if (Oper_Map.get(Operator_stack.peak()) < Oper_Map.get(current)){//栈里面是+-，想push*/
                    Operator_stack.push(current);
                }
            }
        }
        if (!Operator_stack.isEmpty()){
            switch (Operator_stack.pop()){
                case "+" ->{
                    result = todouble(Operand_stack.pop()) + todouble(Operand_stack.pop());
                    Operand_stack.push(String.valueOf(result));
                }
                case "-" ->{
                    result = -(todouble(Operand_stack.pop()) - todouble(Operand_stack.pop()));
                    Operand_stack.push(String.valueOf(result));
                }
                case "*" ->{
                    result = todouble(Operand_stack.pop()) * todouble(Operand_stack.pop());
                    Operand_stack.push(String.valueOf(result));
                }
                case "/" ->{
                    result = 1 / (todouble(Operand_stack.pop()) / todouble(Operand_stack.pop()));
                    Operand_stack.push(String.valueOf(result));
                }
            }
        }
        return Operand_stack.pop();
    }



    //第九题答案
    public String[] outPostfix(String[] infix) {
        String[] postfix = new String[infix.length];
        int index = 0;

        Map<String, Integer> Oper_Map = new HashMap<>();
        Oper_Map.put("+", 1);
        Oper_Map.put("-", 1);
        Oper_Map.put("*", 2);
        Oper_Map.put("/", 2);

        ArrayStack stack = new ArrayStack(infix.length);

        for (int i = 0; i < infix.length; i++){
            String current = infix[i];
            //是否是整数
            if (current.charAt(0) >= '0' && current.charAt(0) <= '9'){
                postfix[index++] = current;
            }else //不是整数，是+-*/ ？ 是括号？
            {
                if (stack.isEmpty()){//保证stack不为空
                    stack.push(current);
                }else if (!isBracket(current)){//当前字符不是括号
                    if (isBracket((String) stack.peak())){//如果前面是括号，直接push进去
                        stack.push(current);
                    }else if (!isBracket((String) stack.peak())){//前面不是括号，就是正常情况，区分优先级

                        if (!Oper_Map.containsKey(stack.peak())){
                            stack.push(current);
                        }

                        else if (Oper_Map.containsKey(stack.peak())&&Oper_Map.get(stack.peak()) < Oper_Map.get(current)) {
                            postfix[index++] = infix[i + 1];
                            postfix[index++] = infix[i];
                            i++;
                        }

                        else  if (Oper_Map.get(stack.peak()) >= Oper_Map.get(current)){
                            postfix[index++] = (String) stack.pop();
                            stack.push(current);
                        }
                    }
                }else if(isBracket(current)){//当前是括号，就要分左括号还是右括号
                    if (current.equals("(")) {
                        //bracket++;
                        stack.push(current);
                    }
                    if (current.equals(")")) {
                        //bracket--;
                        while (!stack.peak().equals("(")) {
                            postfix[index++] = (String) stack.pop();
                        }
                        stack.pop();
                    }
                }
            }
        }
        while (!stack.isEmpty()) {
            postfix[index++] = (String) stack.pop();
        }
        return postfix;
    }

    public static boolean isBracket(String s){
        return s.equals("(") || s.equals(")");
    }


    public double result(String[] postfix) {
        double result = 0;
        ArrayStack computeStack = new ArrayStack(postfix.length);
        for (int i = 0; i < postfix.length && postfix[i] != null; i++) {
            String current = postfix[i];
            //如果不是运算符，则入栈
            if (!isOper(current)) {
                computeStack.push(current);
            }
            //当前字符为运算符，从栈顶取出两个数字运算出结果，并放入栈中
            else {
                switch (current) {
                    case "+" -> {
                        result = todouble(computeStack.pop()) + todouble(computeStack.pop());
                        computeStack.push(String.valueOf(result));
                    }
                    case "-" -> {
                        result = -(todouble(computeStack.pop()) - todouble(computeStack.pop()));
                        computeStack.push(String.valueOf(result));
                    }
                    case "*" -> {
                        result = todouble(computeStack.pop()) * todouble(computeStack.pop());
                        computeStack.push(String.valueOf(result));
                    }
                    case "/" -> {
                        result = 1 / (todouble(computeStack.pop()) / todouble(computeStack.pop()));
                        computeStack.push(String.valueOf(result));
                    }
                    default -> {
                    }
                }
            }
        }
        return result;
    }

    public static double todouble(String str) {
        double num = 0;
        num = Double.parseDouble(str);
        return num;
    }

    public static boolean isOper(String val) {
        return "+".equals(val) || "-".equals(val) || "*".equals(val) || "/".equals(val);
    }
}

