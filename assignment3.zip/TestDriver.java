package INFO6205.assignment23;

import java.io.IOException;

public class TestDriver {
    public static void main(String[] args) throws IOException {

//        People_Link test_people_link = new People_Link();
//        test_people_link.demo();
//
//        People_Array test_people_array = new People_Array();
//        test_people_array.demo();
        /*
        original order for linked list stack:
        People{id=1, firstName='Jack', lastName='Irwan', Course='Software Engineering', first=null, count_size=0, maxSize=0}
        People{id=2, firstName='Billy', lastName='Mckao', Course='Requirement Engineering', first=null, count_size=0, maxSize=0}
        People{id=3, firstName='Nat', lastName='Mcfaden', Course='Multivariate Calculus', first=null, count_size=0, maxSize=0}
        People{id=4, firstName='Steven', lastName='Shwimmer', Course='Software Engineering', first=null, count_size=0, maxSize=0}
        People{id=5, firstName='Ruby', lastName='Jason', Course='Relational DBMS', first=null, count_size=0, maxSize=0}
        People{id=6, firstName='Mark', lastName='Dyne', Course='PHP development', first=null, count_size=0, maxSize=0}
        People{id=7, firstName='Philip', lastName='Namdaf', Course='Microsoft Dot Net Platform', first=null, count_size=0, maxSize=0}
        People{id=8, firstName='Erik', lastName='Bawn', Course='HTMI&Scripting', first=null, count_size=0, maxSize=0}
        People{id=9, firstName='Ricky', lastName='Ben', Course='Data communication', first=null, count_size=0, maxSize=0}
        People{id=10, firstName='Van', lastName='Miecky', Course='Computer Networks', first=null, count_size=0, maxSize=0}
        push 4 elements into stack

        pop 5 elements from stack
        the pop element is: People{id=4, firstName='Steven', lastName='Shwimmer', Course='Software Engineering', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=3, firstName='Nat', lastName='Mcfaden', Course='Multivariate Calculus', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=2, firstName='Billy', lastName='Mckao', Course='Requirement Engineering', first=null, count_size=0, maxSize=0}
        the pop element is: 0
        the pop element is: 0

        push all elements into stack

        push 11 and 12

        pop all elements from stack
        the pop element is: People{id=12, firstName='justin', lastName='morgan', Course='engineering statistics', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=11, firstName='john', lastName='henry', Course='software development', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=10, firstName='Van', lastName='Miecky', Course='Computer Networks', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=9, firstName='Ricky', lastName='Ben', Course='Data communication', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=8, firstName='Erik', lastName='Bawn', Course='HTMI&Scripting', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=7, firstName='Philip', lastName='Namdaf', Course='Microsoft Dot Net Platform', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=6, firstName='Mark', lastName='Dyne', Course='PHP development', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=5, firstName='Ruby', lastName='Jason', Course='Relational DBMS', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=4, firstName='Steven', lastName='Shwimmer', Course='Software Engineering', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=3, firstName='Nat', lastName='Mcfaden', Course='Multivariate Calculus', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=2, firstName='Billy', lastName='Mckao', Course='Requirement Engineering', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=1, firstName='Jack', lastName='Irwan', Course='Software Engineering', first=null, count_size=0, maxSize=0}

        push 8 elements into stack

        pop 9 elements from stack
        the pop element is: People{id=8, firstName='Erik', lastName='Bawn', Course='HTMI&Scripting', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=7, firstName='Philip', lastName='Namdaf', Course='Microsoft Dot Net Platform', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=6, firstName='Mark', lastName='Dyne', Course='PHP development', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=5, firstName='Ruby', lastName='Jason', Course='Relational DBMS', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=4, firstName='Steven', lastName='Shwimmer', Course='Software Engineering', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=3, firstName='Nat', lastName='Mcfaden', Course='Multivariate Calculus', first=null, count_size=0, maxSize=0}
        the pop element is: 0
        the pop element is: 0
        the pop element is: 0

        push all elements into stack

        pop all elements from stack
        the pop element is: People{id=12, firstName='justin', lastName='morgan', Course='engineering statistics', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=11, firstName='john', lastName='henry', Course='software development', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=10, firstName='Van', lastName='Miecky', Course='Computer Networks', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=9, firstName='Ricky', lastName='Ben', Course='Data communication', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=8, firstName='Erik', lastName='Bawn', Course='HTMI&Scripting', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=7, firstName='Philip', lastName='Namdaf', Course='Microsoft Dot Net Platform', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=6, firstName='Mark', lastName='Dyne', Course='PHP development', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=5, firstName='Ruby', lastName='Jason', Course='Relational DBMS', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=4, firstName='Steven', lastName='Shwimmer', Course='Software Engineering', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=3, firstName='Nat', lastName='Mcfaden', Course='Multivariate Calculus', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=2, firstName='Billy', lastName='Mckao', Course='Requirement Engineering', first=null, count_size=0, maxSize=0}
        the pop element is: People{id=1, firstName='Jack', lastName='Irwan', Course='Software Engineering', first=null, count_size=0, maxSize=0}

        original order for array stack:
        People_Array{id=1, firstName='Jack', lastName='Irwan', Course='Software Engineering'}
        People_Array{id=2, firstName='Billy', lastName='Mckao', Course='Requirement Engineering'}
        People_Array{id=3, firstName='Nat', lastName='Mcfaden', Course='Multivariate Calculus'}
        People_Array{id=4, firstName='Steven', lastName='Shwimmer', Course='Software Engineering'}
        People_Array{id=5, firstName='Ruby', lastName='Jason', Course='Relational DBMS'}
        People_Array{id=6, firstName='Mark', lastName='Dyne', Course='PHP development'}
        People_Array{id=7, firstName='Philip', lastName='Namdaf', Course='Microsoft Dot Net Platform'}
        People_Array{id=8, firstName='Erik', lastName='Bawn', Course='HTMI&Scripting'}
        People_Array{id=9, firstName='Ricky', lastName='Ben', Course='Data communication'}
        People_Array{id=10, firstName='Van', lastName='Miecky', Course='Computer Networks'}
        push 4 elements into stack
        4

        pop 5 elements from stack
        the pop element is :People_Array{id=4, firstName='Steven', lastName='Shwimmer', Course='Software Engineering'}
        the pop element is :People_Array{id=3, firstName='Nat', lastName='Mcfaden', Course='Multivariate Calculus'}
        the pop element is :People_Array{id=2, firstName='Billy', lastName='Mckao', Course='Requirement Engineering'}
        the pop element is :People_Array{id=1, firstName='Jack', lastName='Irwan', Course='Software Engineering'}
        the pop element is :0

        push all elements into stack

        push 11 and 12

        pop all elements from stack
        the pop element is :People_Array{id=12, firstName='justin', lastName='morgan', Course='engineering statistics'}
        the pop element is :People_Array{id=11, firstName='john', lastName='henry', Course='software development'}
        the pop element is :People_Array{id=10, firstName='Van', lastName='Miecky', Course='Computer Networks'}
        the pop element is :People_Array{id=9, firstName='Ricky', lastName='Ben', Course='Data communication'}
        the pop element is :People_Array{id=8, firstName='Erik', lastName='Bawn', Course='HTMI&Scripting'}
        the pop element is :People_Array{id=7, firstName='Philip', lastName='Namdaf', Course='Microsoft Dot Net Platform'}
        the pop element is :People_Array{id=6, firstName='Mark', lastName='Dyne', Course='PHP development'}
        the pop element is :People_Array{id=5, firstName='Ruby', lastName='Jason', Course='Relational DBMS'}
        the pop element is :People_Array{id=4, firstName='Steven', lastName='Shwimmer', Course='Software Engineering'}
        the pop element is :People_Array{id=3, firstName='Nat', lastName='Mcfaden', Course='Multivariate Calculus'}
        the pop element is :People_Array{id=2, firstName='Billy', lastName='Mckao', Course='Requirement Engineering'}
        the pop element is :People_Array{id=1, firstName='Jack', lastName='Irwan', Course='Software Engineering'}

        push 8 elements into stack

        pop 9 elements from stack
        the top element is :People_Array{id=8, firstName='Erik', lastName='Bawn', Course='HTMI&Scripting'}
        the top element is :People_Array{id=7, firstName='Philip', lastName='Namdaf', Course='Microsoft Dot Net Platform'}
        the top element is :People_Array{id=6, firstName='Mark', lastName='Dyne', Course='PHP development'}
        the top element is :People_Array{id=5, firstName='Ruby', lastName='Jason', Course='Relational DBMS'}
        the top element is :People_Array{id=4, firstName='Steven', lastName='Shwimmer', Course='Software Engineering'}
        the top element is :People_Array{id=3, firstName='Nat', lastName='Mcfaden', Course='Multivariate Calculus'}
        the top element is :People_Array{id=2, firstName='Billy', lastName='Mckao', Course='Requirement Engineering'}
        the top element is :People_Array{id=1, firstName='Jack', lastName='Irwan', Course='Software Engineering'}
        1
        the top element is :0

        push all elements into stack

        pop all elements from stack
        the pop element is :People_Array{id=12, firstName='justin', lastName='morgan', Course='engineering statistics'}
        the pop element is :People_Array{id=11, firstName='john', lastName='henry', Course='software development'}
        the pop element is :People_Array{id=10, firstName='Van', lastName='Miecky', Course='Computer Networks'}
        the pop element is :People_Array{id=9, firstName='Ricky', lastName='Ben', Course='Data communication'}
        the pop element is :People_Array{id=8, firstName='Erik', lastName='Bawn', Course='HTMI&Scripting'}
        the pop element is :People_Array{id=7, firstName='Philip', lastName='Namdaf', Course='Microsoft Dot Net Platform'}
        the pop element is :People_Array{id=6, firstName='Mark', lastName='Dyne', Course='PHP development'}
        the pop element is :People_Array{id=5, firstName='Ruby', lastName='Jason', Course='Relational DBMS'}
        the pop element is :People_Array{id=4, firstName='Steven', lastName='Shwimmer', Course='Software Engineering'}
        the pop element is :People_Array{id=3, firstName='Nat', lastName='Mcfaden', Course='Multivariate Calculus'}
        the pop element is :People_Array{id=2, firstName='Billy', lastName='Mckao', Course='Requirement Engineering'}
        the pop element is :People_Array{id=1, firstName='Jack', lastName='Irwan', Course='Software Engineering'}



         */


        Postfix_And_Result m = new Postfix_And_Result();

//        String[] infix1 = new String[]{"A", "*", "B", "/", "C", "+", "(", "D", "+", "E", "-", "(", "F", "*", "(","G","/","H",")",")",")"};
//        String[] postfix1 = m.outPostfix(infix1);
//
//        for (int i = 0; i < postfix1.length && infix1[i] != null; i++) {
//            if (postfix1[i] == null){
//                break;
//            }
//            System.out.print(postfix1[i] + " ");
//        }
//         A B * C / D E + F G H / * - +

//        String[] infix2 = new String[]{"(", "1", "+", "3", "+", "(", "(", "4", "/", "2", ")", "*", "(","8","*","4",")",")",")"};
//        String[] postfix2 = m.outPostfix(infix2);
//        System.out.println(m.In_Po_Re(infix2));
//
//        for (int i = 0; i < postfix2.length && infix2[i] != null; i++) {
//            if (postfix2[i] == null){
//                break;
//            }
//            System.out.print(postfix2[i] + " ");
//        }
//        // 1 3 + 4 2 / 8 4 * * +
//        // 68.0


//        String[] infix3 = new String[]{"(", "4", "+", "8", ")","*", "(", "6", "-", "5", ")", "/", "(", "(","3","-","2",")","*","(","2","+","2",")",")"};
//        String[] postfix3 = m.outPostfix(infix3);
//        System.out.println(m.In_Po_Re(infix3));
//        for (int i = 0; i < postfix3.length && infix3[i] != null; i++) {
//            if (postfix3[i] == null){
//                break;
//            }
//            System.out.print(postfix3[i] + " ");
//        }
//        // 4 8 + 6 5 - * 3 2 - 2 2 + * /
//        3.0

//        String[] infix4 = new String[]{"10", "2", "8", "*", "+","3", "-"};
//        System.out.println(m.result(infix4));
//        // 23.0



    }
}









