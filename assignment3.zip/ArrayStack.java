package INFO6205.assignment23;
/*

. Consider String “It was the best of time”.
Start with the first word, design a Stack such that when you read back the words, the order of string does not change.
Provide code for all necessary operations of Stack. Compile and run the code.
 */

public class ArrayStack {
    private int top = -1;
    private Object[] objects;

    public ArrayStack(int capacity){
        objects = new Object[capacity];
    }
    public boolean isEmpty(){return top == -1;}
    public boolean isFull(){return top == objects.length-1;}
    public void push(Object obj){
        if (isFull()){
            System.out.println("Stack is full");
        }
        objects[++top] = obj;
    }
    public Object pop(){
        if (isEmpty()){
            return "Stack is empty";
        }

        return objects[top--];
    }

    public static void main(String[] args) {
        Object[] s = {"time","of","best","the","was","It"};
        ArrayStack stack = new ArrayStack(6);
        for (Object o : s) {
            stack.push(o);
        }
        for (int i=0; i<s.length; i++){
            System.out.print(stack.pop()+" ");
        }
    }
}
/*
time
of
best
the
was
It
 */