package INFO6205.assignment23;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class People_Array {
    private int id;
    private String firstName;
    private String lastName;
    private String Course;

    public People_Array() {
    }

    public People_Array(int id, String firstName, String lastName, String course) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        Course = course;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCourse() {
        return Course;
    }

    public void setCourse(String course) {
        Course = course;
    }

    @Override
    public String toString() {
        return "People_Array{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", Course='" + Course + '\'' +
                '}';
    }

    //创建csv文件，进行写读操作
    public static List<String> FileUtil() throws IOException {
        People_Array p1 = new People_Array(1, "Jack", "Irwan", "Software Engineering");
        People_Array p2 = new People_Array(2, "Billy", "Mckao", "Requirement Engineering");
        People_Array p3 = new People_Array(3, "Nat", "Mcfaden", "Multivariate Calculus");
        People_Array p4 = new People_Array(4, "Steven", "Shwimmer", "Software Engineering");
        People_Array p5 = new People_Array(5, "Ruby", "Jason", "Relational DBMS");
        People_Array p6 = new People_Array(6, "Mark", "Dyne", "PHP development");
        People_Array p7 = new People_Array(7, "Philip", "Namdaf", "Microsoft Dot Net Platform");
        People_Array p8 = new People_Array(8, "Erik", "Bawn", "HTMI&Scripting");
        People_Array p9 = new People_Array(9, "Ricky", "Ben", "Data communication");
        People_Array p10 = new People_Array(10, "Van", "Miecky", "Computer Networks");

        BufferedWriter bw = new BufferedWriter(new FileWriter("/input2.txt"));
        List<People_Array> peopleList = new ArrayList<>();
        peopleList.add(p1);
        peopleList.add(p2);
        peopleList.add(p3);
        peopleList.add(p4);
        peopleList.add(p5);
        peopleList.add(p6);
        peopleList.add(p7);
        peopleList.add(p8);
        peopleList.add(p9);
        peopleList.add(p10);
        for (People_Array people : peopleList) {
            bw.write(people.getId() + "," + people.getFirstName() + "," + people.getLastName() + "," + people.getCourse());
            bw.newLine();
            bw.flush();
        }
        bw.close();

        BufferedReader br = new BufferedReader(new FileReader("input2.txt"));
        String peopleTXT = null;
        List<String> peopleData = new ArrayList<>();
        while ((peopleTXT = br.readLine()) != null) {
            peopleData.add(peopleTXT);
        }
        br.close();
        return peopleData;
    }
    //split csv文件，得到People的ArrayList
    public List<People_Array> splitString() throws IOException {
        List<String> strings = People_Link.FileUtil();
        List<People_Array> Pinfors = new ArrayList<>();

        for (String infor : strings) {
            String[] s = infor.split(",");
            int id = Integer.parseInt(s[0]);
            People_Array pinfor = new People_Array();
            pinfor.setId(id);
            pinfor.setFirstName(s[1]);
            pinfor.setLastName(s[2]);
            pinfor.setCourse(s[3]);
            Pinfors.add(pinfor);
        }
        return Pinfors;
    }

    private class Stack_Array{
        private int top = -1;
        private Object[] arr;

        public Stack_Array(int capacity){ arr = new Object[capacity];}
        public int size(){return top+1;}
        public boolean is_empty(){ return top == -1;}
        public boolean is_full(){ return top == arr.length-1;}

        public void push(Object i){
            if (is_full()){
                System.out.println("Stack is full!");
            }
            arr[++top] = i;
        }
        public Object pop(){
            if (is_empty()){
                System.out.println("Stack is empty!");
                System.exit(1);
            }
            return arr[top--];
        }
        public void resize(Stack_Array array, int i){
            for (int n = 0; n < i; n++){
                array.push(0);
            }
        }
    }

    public void demo() throws IOException {
        People_Array function = new People_Array();
        List<People_Array> peopleList = function.splitString();
        System.out.println("\noriginal order for array stack:");
        for (People_Array people : peopleList){
            System.out.println(people);
        }
        Stack_Array stack_array = new Stack_Array(peopleList.size());
        //入栈4个元素
        System.out.println("push 4 elements into stack");
        stack_array.push(peopleList.get(0));
        stack_array.push(peopleList.get(1));
        stack_array.push(peopleList.get(2));
        stack_array.push(peopleList.get(3));
        System.out.println(stack_array.size());

        //出栈5个元素
        System.out.println("\npop 5 elements from stack");
        for (int i = 0; i < 5; i++){
            if ( stack_array.size() == 0){
                stack_array.resize(stack_array, 5-i );
            }
            System.out.println("the pop element is :"+stack_array.pop());
        }

        //入栈全部元素
        System.out.println("\npush all elements into stack");
        for (People_Array person : peopleList){
            stack_array.push(person);
        }

        System.out.println("\npush 11 and 12");
        People_Array p11 = new People_Array(11,"john","henry","software development");
        People_Array p12 = new People_Array(12,"justin","morgan","engineering statistics");

        peopleList.add(p11);
        peopleList.add(p12);
        Stack_Array stack_array_new = new Stack_Array(peopleList.size());
        for (People_Array  p : peopleList){
            stack_array_new.push(p);
        }

        System.out.println("\npop all elements from stack");
        for (int i = 0; i < peopleList.size(); i++){
            System.out.println("the pop element is :"+stack_array_new.pop());
        }

        System.out.println("\npush 8 elements into stack");
        for (int i = 0; i < 8; i++){
            stack_array_new.push(peopleList.get(i));
        }

        System.out.println("\npop 9 elements from stack");
        for (int i = 0; i < 9; i++){
            if ( stack_array_new.size() == 0){
                System.out.println("1");
                stack_array.resize(stack_array_new, 9-i );
            }
            System.out.println("the top element is :"+stack_array_new.pop());
        }

        System.out.println("\npush all elements into stack");
        for (People_Array person : peopleList){
            stack_array_new.push(person);
        }

        System.out.println("\npop all elements from stack");
        for (int i = 0; i < peopleList.size(); i++){
            System.out.println("the pop element is :"+stack_array_new.pop());
        }
    }
}
