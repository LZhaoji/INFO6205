package INFO6205.assignment23;

public class Factorial {
    private static int[] int_list;
    private static int top = -1;

    public Factorial(int capacity){
        int_list = new int[capacity];
    }

    public static boolean isEmpty(){return top == -1;}
    public boolean isFull(){return top == int_list.length-1;}
    public void push(int  i){
        if (isFull()){
            System.out.println("Stack is full");
        }
        int_list[++top] = i;
    }
    public static int pop(){
        if (isEmpty()){
            System.exit(1);
        }
        return int_list[top--];
    }

    public static int Factorial_Multiple(int i){
        if (i <=2){
            return i;
        }
        return pop()*Factorial_Multiple(i-1);
    }

    public static void main(String[] args) {
//        int[] s = {1,2,3,4,5,6,7,8};
        int[] s = {1,2,3,4,5,6};
        long startTime = System.currentTimeMillis(); //获取开始时间
        Factorial factorial = new Factorial(s.length);
        for (int o : s) {
            factorial.push(o);
        }
        int factorial_multiple = Factorial_Multiple(s.length);
        System.out.println(factorial_multiple);
        long endTime = System.currentTimeMillis(); //获取结束时间
        System.out.println("程序运行时间：" + (endTime - startTime) + "ms"); //输出程序运行时间
    }
}

/*
720
程序运行时间：1ms
 */
