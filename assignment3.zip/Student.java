package INFO6205.assignment23;


import java.util.Random;


/*
Write a Java program to define a Student class with instance variables name, id, homework, mid-term, and final.
Name is a string whereas others are all integers. Also, add a static variable nextId, which is an integer and statically initialized to 1.
Have some overloaded constructors. In each of them, the id should be assigned to the next available id given by nextId.
The default constructor should set the name of the student object to “StudentX” where X is the next id. Add a calculateGrade() method
which returns a string for the letter grade of the student, like “A”, “B”, “C”, “D” or “F”, based on the overall score.
Overall score should be calculated as (40% home-works, + 30% midterm + 30% final).
 */
/*
Write TestDriver to test your program. It should create 5 student objects with default constructor
and invoke the setter methods for homeworks, midterm, and final with random numbers ranging
from 50 to 100 inclusive.
Then it should print the student information via the toString() method.
Student information provided by toString() should include name, midterm, project, and final and
the letter grade given by the calculateGrade() method.
 */
public class Student {
    private String name;
    private int id;
    private int homework;
    private int mid_term_score;
    private int project_score;
    private int final_score;
    static int next_id = 1;
    Random r = new Random();

    public Student(String name, int id , int homework, int mid_term_score, int project_score, int final_score) {
        this.name = name;
        this.id = next_id;
        this.homework = homework;
        this.mid_term_score = mid_term_score;
        this.project_score = project_score;
        this.final_score = final_score;
        next_id++;
    }

    public Student() {
        name = "Student"+id;
        id = next_id;
        next_id++;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getHomework() {
        return homework;
    }

    public void setHomework(int homework) {
        this.homework = homework;
    }

    public int getMid_term_score() {
        return mid_term_score;
    }

    public void setMid_term_score(int mid_term_score) {
        this.mid_term_score = mid_term_score;
    }

    public int getFinal_score() {
        return final_score;
    }

    public void setFinal_score(int final_score) {
        this.final_score = final_score;
    }

    public int getProject_score() {
        return project_score;
    }

    public void setProject_score(int project_score) {
        this.project_score = project_score;
    }

    @Override
    public String toString() {
        return  "Hi, I'm " + name +
                ",ID is :" + id +
                ". In 2022 Spring term, "+
                "my homework score is:" + homework +
                ", mid_term_score is:" + mid_term_score +
                ", final_score is:" + final_score +
               " and the final Grade is:" + calculateGrade();
    }

    public String calculateGrade(){
        //40% home-works, + 30% midterm + 30% final
        int grade = (int) (this.getHomework()*0.4+this.getMid_term_score()*0.3+this.getFinal_score()*0.3);
        if (grade >= 90){
            return "A";
        }else if (grade >= 80){
            return "B";
        }else if (grade >= 70){
            return "C";
        }else if (grade >= 60){
            return "D";
        }else {
            return "F";
        }
    }

    public static void main(String[] args) {
        Random r = new Random();

        Student s1 = new Student();
        s1.setHomework(r.nextInt(50,100));
        s1.setMid_term_score(r.nextInt(50,100));
        s1.setFinal_score(r.nextInt(50,100));
        System.out.println(s1);

        Student s2 = new Student();
        s2.setHomework(r.nextInt(50,100));
        s2.setMid_term_score(r.nextInt(50,100));
        s2.setFinal_score(r.nextInt(50,100));
        System.out.println(s2);

        Student s3 = new Student();
        s3.setHomework(r.nextInt(50,100));
        s3.setMid_term_score(r.nextInt(50,100));
        s3.setFinal_score(r.nextInt(50,100));
        System.out.println(s3);

        Student s4 = new Student();
        s4.setHomework(r.nextInt(50,100));
        s4.setMid_term_score(r.nextInt(50,100));
        s4.setFinal_score(r.nextInt(50,100));
        System.out.println(s4);

        Student s5 = new Student();
        s5.setHomework(r.nextInt(50,100));
        s5.setMid_term_score(r.nextInt(50,100));
        s5.setFinal_score(r.nextInt(50,100));
        System.out.println(s5);
    }
}

/*
output:
Hi, I'm Student1,ID is :1. In 2022 Spring term, my homework score is:84, mid_term_score is:96, final_score is:90 and the final Grade is:B
Hi, I'm Student2,ID is :2. In 2022 Spring term, my homework score is:51, mid_term_score is:89, final_score is:67 and the final Grade is:D
Hi, I'm Student3,ID is :3. In 2022 Spring term, my homework score is:59, mid_term_score is:79, final_score is:75 and the final Grade is:D
Hi, I'm Student4,ID is :4. In 2022 Spring term, my homework score is:74, mid_term_score is:56, final_score is:90 and the final Grade is:C
Hi, I'm Student5,ID is :5. In 2022 Spring term, my homework score is:80, mid_term_score is:83, final_score is:51 and the final Grade is:C
 */
