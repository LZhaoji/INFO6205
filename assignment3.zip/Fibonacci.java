package INFO6205.assignment23;

public class Fibonacci {

    public static void main(String[] args) {
        System.out.println("n=7:");
        int N = 7;
        for (int i = 0; i < N; i++) {

            System.out.print(Fibonacci_Sequence(i) + " ");
        }
        System.out.println("\nn=6:");
        int U = 6;
        for (int i = 0; i < U; i++) {

            System.out.print(Fibonacci_Sequence(i) + " ");
        }
        System.out.println("Dynamic Programming, n = 6 is :"+Fibonacci_Easy(6));
        System.out.println("Dynamic Programming, n = 7 is :"+Fibonacci_Easy(7));
    }

    //brute force
    public static int Fibonacci_Sequence(int i) {
        if (i < 2){
            return i;
        }
        return Fibonacci_Sequence(i-1)+Fibonacci_Sequence(i-2);
    }

    //Dynamic programming
    public static int Fibonacci_Easy(int n){

        if (n <= 1){
            return n;
        }
        int[] record = new int[n + 1];
        record[0] = 0;
        record[1] = 1;
        for (int i = 2; i <= n; i++){
            record[i] = record[i - 1] + record[i - 2];
        }
        return record[n];

    }
}
/*
n=7:
0 1 1 2 3 5 8
n=6:
0 1 1 2 3 5
Process finished with exit code 0

 */