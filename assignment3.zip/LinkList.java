package INFO6205.assignment23;
/*
. Consider String “It was the best of time”.
Start with the first word, design a Stack such that when you read back the words, the order of string does not change.
Provide code for all necessary operations of Stack. Compile and run the code.
 */



public class LinkList {

    private static class Node {
        Object item;
        Node next;

        public Node(Object i) {
            this.item = i;
            this.next = null;
        }
    }

    private Node first;
    private int N = 0;

    public boolean isEmpty() { return N == 0; }
    //当前栈的大小
    public int size() { return N; }

    public void push(Object i) {
        Node node = new Node(i);

        Node oldFirst = first;
        first = node;
        first.next = oldFirst;
        N++;
    }
    //栈顶元素
    public Object peek() {
        if (first == null)
            return null;
        return first.item;
    }

    public Object pop() {
        if (isEmpty())
            return "stack is empty";
        Object item = first.item;
        first = first.next;
        N--;
        return item;
    }

    public static void main(String[] args) {
        Object[] s = {"It", "was", "the", "best", "of", "time"};
        LinkList stack = new LinkList();
        for (Object o : s) {
            stack.push(o);
        }
        for (int i=0; i<s.length; i++){
            System.out.println(stack.pop());
        }
    }
}
/*
time
of
best
the
was
It
 */