package INFO6205.assignment23;

import java.io.*;
import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.List;

public class People_Link {
    private int id;
    private String firstName;
    private String lastName;
    private String Course;

    public People_Link() {}

    public People_Link(int id, String firstName, String lastName, String course) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        Course = course;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCourse() {
        return Course;
    }

    public void setCourse(String course) {
        Course = course;
    }

    @Override
    public String toString() {
        return "People{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", Course='" + Course + '\'' +
                ", first=" + first +
                ", count_size=" + count_size +
                ", maxSize=" + maxSize +
                '}';
    }

    //创建csv文件，进行写读操作
    public static List<String> FileUtil() throws IOException {
        People_Link p1 = new People_Link(1, "Jack", "Irwan", "Software Engineering");
        People_Link p2 = new People_Link(2, "Billy", "Mckao", "Requirement Engineering");
        People_Link p3 = new People_Link(3, "Nat", "Mcfaden", "Multivariate Calculus");
        People_Link p4 = new People_Link(4, "Steven", "Shwimmer", "Software Engineering");
        People_Link p5 = new People_Link(5, "Ruby", "Jason", "Relational DBMS");
        People_Link p6 = new People_Link(6, "Mark", "Dyne", "PHP development");
        People_Link p7 = new People_Link(7, "Philip", "Namdaf", "Microsoft Dot Net Platform");
        People_Link p8 = new People_Link(8, "Erik", "Bawn", "HTMI&Scripting");
        People_Link p9 = new People_Link(9, "Ricky", "Ben", "Data communication");
        People_Link p10 = new People_Link(10, "Van", "Miecky", "Computer Networks");

        BufferedWriter bw = new BufferedWriter(new FileWriter("/input.txt"));
        List<People_Link> peopleList = new ArrayList<>();
        peopleList.add(p1);
        peopleList.add(p2);
        peopleList.add(p3);
        peopleList.add(p4);
        peopleList.add(p5);
        peopleList.add(p6);
        peopleList.add(p7);
        peopleList.add(p8);
        peopleList.add(p9);
        peopleList.add(p10);
        for (People_Link people : peopleList) {
            bw.write(people.getId() + "," + people.getFirstName() + "," + people.getLastName() + "," + people.getCourse());
            bw.newLine();
            bw.flush();
        }
        bw.close();

        BufferedReader br = new BufferedReader(new FileReader("input.txt"));
        String peopleTXT = null;
        List<String> peopleData = new ArrayList<>();
        while ((peopleTXT = br.readLine()) != null) {
            peopleData.add(peopleTXT);
        }
        br.close();
        return peopleData;
    }
    //split csv文件，得到People的ArrayList
    public List<People_Link> splitString() throws IOException {
        List<String> strings = People_Link.FileUtil();
        List<People_Link> Pinfors = new ArrayList<>();

        for (String infor : strings) {
            String[] s = infor.split(",");
            int id = Integer.parseInt(s[0]);
            People_Link pinfor = new People_Link();
            pinfor.setId(id);
            pinfor.setFirstName(s[1]);
            pinfor.setLastName(s[2]);
            pinfor.setCourse(s[3]);
            Pinfors.add(pinfor);
        }
        return Pinfors;
    }

    private static class Node{
        Object item;
        Node next;//上一个的下标

        public Node(Object i){
            this.item = i;
            this.next = null;
        }
    }
    private Node first;//现在的下标
    private int count_size = 0;//当前栈大小
    private int maxSize;//栈最大值设定

    public void setMaxSize(int maxSize) {
        this.maxSize = maxSize;
    }

    public boolean is_empty(){return count_size == 0;}
    public boolean is_full(){return count_size == maxSize;}

    public int size(){return count_size;}

    public void push(Object item){
        Node node = new Node(item);

        Node oldFirst = first;
        first = node;
        first.next = oldFirst;
        count_size++;
    }
    public void pop() {
        if (is_empty()) {
            System.out.println("Your Stack is Empty!");
            throw new EmptyStackException();
        }
        Object item = first.item;
        System.out.println("the pop element is: " + item);
        first = first.next;//把当前指针指向上一个node的地址
        count_size--;
    }
    public People_Link resize(People_Link node_link,int i){
        for (int n = 0; n < i; n++){
            node_link.push(0);
        }
        return node_link;
    }

    public void demo() throws IOException {
        People_Link function = new People_Link();
        List<People_Link> peopleList = function.splitString();
        System.out.println("original order for linked list stack:");
        for (People_Link people : peopleList){
            System.out.println(people);
        }
        //入栈4个元素
        System.out.println("push 4 elements into stack");
        function.push(peopleList.get(0));
        function.push(peopleList.get(1));
        function.push(peopleList.get(2));
        function.push(peopleList.get(3));

        //出栈5个元素
        System.out.println("\npop 5 elements from stack");
        for (int i = 0; i < 5; i++){
            if ( i > function.size()){
                function = resize(function,i - function.size());
            }
            function.pop();
        }

        //入栈全部元素
        System.out.println("\npush all elements into stack");
        for (People_Link person : peopleList){
            function.push(person);
        }

        System.out.println("\npush 11 and 12");
        People_Link p11 = new People_Link(11,"john","henry","software development");
        People_Link p12 = new People_Link(12,"justin","morgan","engineering statistics");
        function.push(p11);
        function.push(p12);
        peopleList.add(p11);
        peopleList.add(p12);

        System.out.println("\npop all elements from stack");
        for (int i = 0; i < peopleList.size(); i++){
            function.pop();
        }

        System.out.println("\npush 8 elements into stack");
        for (int i = 0; i < 8; i++){
            function.push(peopleList.get(i));
        }

        System.out.println("\npop 9 elements from stack");
        for (int i = 0; i < 9; i++){
            if ( i > function.size()){
                function = resize(function,i - function.size());
            }
            function.pop();
        }

        System.out.println("\npush all elements into stack");
        for (People_Link person : peopleList){
            function.push(person);
        }

        System.out.println("\npop all elements from stack");
        for (int i = 0; i < peopleList.size(); i++){
           function.pop();
        }
    }
}
