package INFO6205.assignment4;


import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class People_linklist {
    private class Node{
        Object item;
        Node next;
        public Node(Object item){
            this.item = item;
            this.next = null;
        }
    }
    Node first;
    int current_size;
    public boolean isEmpty(){return current_size == 0;}
    public void enqueue(Object item){
        Node node = new Node(item);
        Node oldNode = first;
        first = node;
        first.next = oldNode;
//        if (isEmpty()) first = node;
//        else oldNode.next = node;
        current_size++;
    }
    public Object dequeue(){
        //if (isEmpty())return "queue is empty";
        Object item = first.item;
        first = first.next;
//        if (isEmpty()) first = null;
        current_size--;
        return item;
    }

    private int id;
    private String firstName;
    private String lastName;
    private String Course;

    public People_linklist() {}

    public People_linklist(int id, String firstName, String lastName, String course) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        Course = course;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCourse() {
        return Course;
    }

    public void setCourse(String course) {
        Course = course;
    }

    @Override
    public String toString() {
        return "People{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", Course='" + Course + '\'' +
                ", first=" + first +
                '}';
    }

    //创建csv文件，进行写读操作
    public static List<String> FileUtil() throws IOException {
        People_linklist p1 = new People_linklist(1, "Jack", "Irwan", "Software Engineering");
        People_linklist p2 = new People_linklist(2, "Billy", "Mckao", "Requirement Engineering");
        People_linklist p3 = new People_linklist(3, "Nat", "Mcfaden", "Multivariate Calculus");
        People_linklist p4 = new People_linklist(4, "Steven", "Shwimmer", "Software Engineering");
        People_linklist p5 = new People_linklist(5, "Ruby", "Jason", "Relational DBMS");
        People_linklist p6 = new People_linklist(6, "Mark", "Dyne", "PHP development");
        People_linklist p7 = new People_linklist(7, "Philip", "Namdaf", "Microsoft Dot Net Platform");
        People_linklist p8 = new People_linklist(8, "Erik", "Bawn", "HTMI&Scripting");
        People_linklist p9 = new People_linklist(9, "Ricky", "Ben", "Data communication");
        People_linklist p10 = new People_linklist(10, "Van", "Miecky", "Computer Networks");

        BufferedWriter bw = new BufferedWriter(new FileWriter("/input.txt"));
        List<People_linklist> peopleList = new ArrayList<>();
        peopleList.add(p1);
        peopleList.add(p2);
        peopleList.add(p3);
        peopleList.add(p4);
        peopleList.add(p5);
        peopleList.add(p6);
        peopleList.add(p7);
        peopleList.add(p8);
        peopleList.add(p9);
        peopleList.add(p10);
        for (People_linklist people : peopleList) {
            bw.write(people.getId() + "," + people.getFirstName() + "," + people.getLastName() + "," + people.getCourse());
            bw.newLine();
            bw.flush();
        }
        bw.close();

        BufferedReader br = new BufferedReader(new FileReader("/input.txt"));
        String peopleTXT = null;
        List<String> peopleData = new ArrayList<>();
        while ((peopleTXT = br.readLine()) != null) {
            peopleData.add(peopleTXT);
        }
        br.close();
        return peopleData;
    }
    //split csv文件，得到People的ArrayList
    public List<People_linklist> splitString() throws IOException {
        List<String> strings = People_linklist.FileUtil();
        List<People_linklist> Pinfors = new ArrayList<>();

        for (String infor : strings) {
            String[] s = infor.split(",");
            int id = Integer.parseInt(s[0]);
            People_linklist pinfor = new People_linklist();
            pinfor.setId(id);
            pinfor.setFirstName(s[1]);
            pinfor.setLastName(s[2]);
            pinfor.setCourse(s[3]);
            Pinfors.add(pinfor);
        }
        return Pinfors;
    }

    public void demo() throws IOException {
        People_linklist function = new People_linklist();
        List<People_linklist> peopleList = function.splitString();
        System.out.println("original order for linked list stack:");
        for (People_linklist people : peopleList){
            System.out.println(people);
        }

        System.out.println("enqueue all elements into queue");
        for (People_linklist person : peopleList){
            function.enqueue(person);
        }


        System.out.println("\ndequeue 4 elements from queue");
        for (int i = 0; i < 4; i++){
            System.out.println(function.dequeue());
        }


        System.out.println("\nenqueue all elements into queue");
        for (People_linklist person : peopleList){
            function.enqueue(person);
        }
        System.out.println("\ndequeue all elements from queue");
        for (int i = 0; i < peopleList.size(); i++){
            System.out.println(function.dequeue());
        }

        System.out.println("\ndequeue 2 element");
        for (int i = 0; i < 2; i++){
            System.out.println(function.dequeue());
        }

        System.out.println("\nenqueue all elements into queue");
        for (People_linklist person : peopleList){
            function.enqueue(person);
        }

        People_linklist p11 = new People_linklist(11,"john","henry","software development");
        People_linklist p12 = new People_linklist(12,"Raj","Manish","Statistician");
        People_linklist p13 = new People_linklist(13,"Justin","Morgan","engineering statistics");
        function.enqueue(p11);
        function.enqueue(p12);
        function.enqueue(p13);
    }
}
