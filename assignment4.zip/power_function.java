package INFO6205.assignment4;

public class power_function {
    /*
    For Iterative algorithm, we can use a for loop to solve
    do the loop for the exponentiation times
    time complexity is O(N)
     */
    public int Iteration_solve(int num1,int num2){
        int result = 1;
        for (int i = 0; i < num2; i++){
            result = result * num1;
        }
        return result;
    }

    // the brute force, calculate each num1^(from num2 to 0) time complexity is O(N)
    public int Recursive_solve(int num1,int num2){
        if ( num2 == 1){
            return num1*num2;
        }
        return num1*Recursive_solve(num1,num2-1);
    }

    /*
    dynamic programming, how to recode the num1^num2
    if num2 is even, num1^num2 = num1^(num2/2) * num1^(num2/2)
    if num2 is odd, num1^num2 = num1^(num2/2) * num1^(num2/2) * num1
    and we use a variable to recode the result of num1^(num2/2)
    time complexity is O(logN)
     */
    public int Recursive_solve_dy(int num1,int num2){
        if (num2 == 0){return 1;}
        int pow = Recursive_solve_dy(num1,num2/2);
        if (num2%2 == 0){
            return pow * pow;
        }
        return num1 * pow * pow;
    }

    public static void main(String[] args) {
        power_function p = new power_function();
        System.out.println(p.Iteration_solve(2,10));
        System.out.println(p.Recursive_solve(2,10));
        System.out.println(p.Recursive_solve_dy(2,9));
    }
}
