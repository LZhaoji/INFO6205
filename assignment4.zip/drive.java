package INFO6205.assignment4;

import java.io.IOException;
import java.util.Arrays;

public class drive {

    private static int a;

    public static void main(String[] args) throws IOException {
//        People_linklist p = new People_linklist();
//        p.demo();
//        People_arrray p = new People_arrray();
//        p.demo();

//        Postfix po = new Postfix();
//        String[] infix1 = new String[]{"(", "A", "+", "B", ")", "*", "C", "+", "D", "/", "(", "E", "+", "F", "*","G",")","-","H"};
//        System.out.println(Arrays.toString(po.outPostfix(infix1)));
////
//        //(1 + 3 + ( ( 4 / 2 ) * ( 8 * 4 ) ))
//        String[] infix2 = new String[]{"(", "1", "+", "3", "+", "(", "(", "4", "/", "2", ")", "*", "(", "8", "*","4",")",")",")"};
//        String[] postfix = po.outPostfix(infix2);
//        System.out.println(Arrays.toString(postfix));
//        System.out.println(po.getInfix(postfix));
        int hs = Integer.hashCode(1);
        int sh = Integer.hashCode(2);
        System.out.println(hs == sh);
    }
}
/*
original order for array stack:
People_Array{id=1, firstName='Jack', lastName='Irwan', Course='Software Engineering'}
People_Array{id=2, firstName='Billy', lastName='Mckao', Course='Requirement Engineering'}
People_Array{id=3, firstName='Nat', lastName='Mcfaden', Course='Multivariate Calculus'}
People_Array{id=4, firstName='Steven', lastName='Shwimmer', Course='Software Engineering'}
People_Array{id=5, firstName='Ruby', lastName='Jason', Course='Relational DBMS'}
People_Array{id=6, firstName='Mark', lastName='Dyne', Course='PHP development'}
People_Array{id=7, firstName='Philip', lastName='Namdaf', Course='Microsoft Dot Net Platform'}
People_Array{id=8, firstName='Erik', lastName='Bawn', Course='HTMI&Scripting'}
People_Array{id=9, firstName='Ricky', lastName='Ben', Course='Data communication'}
People_Array{id=10, firstName='Van', lastName='Miecky', Course='Computer Networks'}
enqueue all elements into queue

dequeue 4 elements from queue
People_Array{id=10, firstName='Van', lastName='Miecky', Course='Computer Networks'}
People_Array{id=9, firstName='Ricky', lastName='Ben', Course='Data communication'}
People_Array{id=8, firstName='Erik', lastName='Bawn', Course='HTMI&Scripting'}
People_Array{id=7, firstName='Philip', lastName='Namdaf', Course='Microsoft Dot Net Platform'}

enqueue all elements into queue

dequeue all elements from queue
People_Array{id=6, firstName='Mark', lastName='Dyne', Course='PHP development'}
People_Array{id=5, firstName='Ruby', lastName='Jason', Course='Relational DBMS'}
People_Array{id=4, firstName='Steven', lastName='Shwimmer', Course='Software Engineering'}
People_Array{id=3, firstName='Nat', lastName='Mcfaden', Course='Multivariate Calculus'}
People_Array{id=2, firstName='Billy', lastName='Mckao', Course='Requirement Engineering'}
People_Array{id=1, firstName='Jack', lastName='Irwan', Course='Software Engineering'}
People_Array{id=10, firstName='Van', lastName='Miecky', Course='Computer Networks'}
People_Array{id=9, firstName='Ricky', lastName='Ben', Course='Data communication'}
People_Array{id=8, firstName='Erik', lastName='Bawn', Course='HTMI&Scripting'}
People_Array{id=7, firstName='Philip', lastName='Namdaf', Course='Microsoft Dot Net Platform'}

dequeue 2 element
People_Array{id=6, firstName='Mark', lastName='Dyne', Course='PHP development'}
People_Array{id=5, firstName='Ruby', lastName='Jason', Course='Relational DBMS'}

enqueue all elements into queue

Process finished with exit code 0


original order for linked list stack:
People{id=1, firstName='Jack', lastName='Irwan', Course='Software Engineering', first=null}
People{id=2, firstName='Billy', lastName='Mckao', Course='Requirement Engineering', first=null}
People{id=3, firstName='Nat', lastName='Mcfaden', Course='Multivariate Calculus', first=null}
People{id=4, firstName='Steven', lastName='Shwimmer', Course='Software Engineering', first=null}
People{id=5, firstName='Ruby', lastName='Jason', Course='Relational DBMS', first=null}
People{id=6, firstName='Mark', lastName='Dyne', Course='PHP development', first=null}
People{id=7, firstName='Philip', lastName='Namdaf', Course='Microsoft Dot Net Platform', first=null}
People{id=8, firstName='Erik', lastName='Bawn', Course='HTMI&Scripting', first=null}
People{id=9, firstName='Ricky', lastName='Ben', Course='Data communication', first=null}
People{id=10, firstName='Van', lastName='Miecky', Course='Computer Networks', first=null}
enqueue all elements into queue

dequeue 4 elements from queue
People{id=10, firstName='Van', lastName='Miecky', Course='Computer Networks', first=null}
People{id=9, firstName='Ricky', lastName='Ben', Course='Data communication', first=null}
People{id=8, firstName='Erik', lastName='Bawn', Course='HTMI&Scripting', first=null}
People{id=7, firstName='Philip', lastName='Namdaf', Course='Microsoft Dot Net Platform', first=null}

enqueue all elements into queue

dequeue all elements from queue
People{id=10, firstName='Van', lastName='Miecky', Course='Computer Networks', first=null}
People{id=9, firstName='Ricky', lastName='Ben', Course='Data communication', first=null}
People{id=8, firstName='Erik', lastName='Bawn', Course='HTMI&Scripting', first=null}
People{id=7, firstName='Philip', lastName='Namdaf', Course='Microsoft Dot Net Platform', first=null}
People{id=6, firstName='Mark', lastName='Dyne', Course='PHP development', first=null}
People{id=5, firstName='Ruby', lastName='Jason', Course='Relational DBMS', first=null}
People{id=4, firstName='Steven', lastName='Shwimmer', Course='Software Engineering', first=null}
People{id=3, firstName='Nat', lastName='Mcfaden', Course='Multivariate Calculus', first=null}
People{id=2, firstName='Billy', lastName='Mckao', Course='Requirement Engineering', first=null}
People{id=1, firstName='Jack', lastName='Irwan', Course='Software Engineering', first=null}

dequeue 2 element
People{id=6, firstName='Mark', lastName='Dyne', Course='PHP development', first=null}
People{id=5, firstName='Ruby', lastName='Jason', Course='Relational DBMS', first=null}

enqueue all elements into queue


[A, B, +, C, *, D, E, F, G, *, +, /, H, -, +]

[1, 3, +, 4, 2, /, 8, 4, *, *, +]

((1+3)+((4/2)*(8*4)))
 */