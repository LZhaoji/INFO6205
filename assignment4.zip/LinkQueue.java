package INFO6205.assignment4;

public class LinkQueue {
    private class Node{
        Object item;
        Node next;
        public Node(Object item){
            this.item = item;
            this.next = null;
        }
    }
    Node first;
    int current_size;
    public boolean isEmpty(){return current_size == 0;}
    public void enqueue(Object item){
        Node node = new Node(item);
        Node oldNode = first;
        first = node;
        first.next = oldNode;
        current_size++;
    }
    public void dequeue(){
        Object item = first.item;
        System.out.println("remove : " + item );
        first = first.next;
    }
}
