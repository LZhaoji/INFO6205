package INFO6205.assignment4;

public class ArrayQueue<T> {
    int rear;
    int front;
    int maximum_size;
    int current_size;
    Object[] arr;

    public ArrayQueue(){}
    public ArrayQueue(int size){
        rear = -1;
        front = 0;
        current_size = 0;
        maximum_size = size;
        arr = new Object[size];
    }
    public int size(){return current_size;}
    public boolean isFull(){return size() == maximum_size;}
    public boolean isEmpty(){return size() == 0;}
    public void enqueue(Object item){
        if (current_size == arr.length){
            resize(arr.length*2);
        }
        if (current_size > 0 && current_size == arr.length/4){
            resize(arr.length/2);
        }
        rear = (rear + 1) % maximum_size;
        arr[rear] = item;
        current_size++;
    }
    public void dequeue(){
        if (isEmpty()){
            System.out.println("stack is empty");
            System.exit(1);
        }
        System.out.println("remove :" + arr[front]);
        front = (front + 1) % maximum_size;
        current_size--;
    }
    public Object peek(){
        return arr[rear];
    }
    public void resize(int size){
        Object[] copy = new Object[size];
        for (int i = 0; i < arr.length; i++){
            copy[i] = arr[i];
        }
        arr = copy;
    }

}