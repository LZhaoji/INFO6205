package INFO6205.assignment4;


import java.util.EmptyStackException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class Postfix {
    public Postfix() {}
    static class ArrayStack {
        private int top = -1;
        private String[] objects;
        private int current_size;

        public ArrayStack(int capacity) {
            objects = new String[capacity];
        }
        public int size(){return top+1;}

        public boolean isEmpty() {
            return top == -1;
        }

        public boolean isFull() {
            return top == objects.length - 1;
        }

        public void push(String obj) {
            if (isFull()) {
                resize(2* objects.length);
            }
            if (current_size > 0 && current_size == objects.length/4){
                resize(objects.length/2);
            }
            objects[++top] = obj;
            current_size++;
        }

        public String pop() {
            if (isEmpty()) {
                return "Stack is empty";
            }
            String value = objects[top];
            top--;
            current_size--;
            return value;
        }

        public String peak() {
            if ( isEmpty()) {
                //return (T) arr[top];
                throw new EmptyStackException();
            }
            return objects[top];
        }

        public void resize(int capacity) {
            String[] copy = new String[capacity];
            if (top + 1 >= 0) System.arraycopy(objects, 0, copy, 0, top + 1);
            objects = copy;
        }

    }

    public String[] outPostfix(String[] infix) {
        String[] postfix = new String[infix.length-getBrace(infix)];
        int index = 0;

        Map<String, Integer> Oper_Map = new HashMap<>();
        Oper_Map.put("+", 1);
        Oper_Map.put("-", 1);
        Oper_Map.put("*", 2);
        Oper_Map.put("/", 2);

        ArrayStack stack = new ArrayStack(infix.length);
        //(A + B) * C + D / (E + F * G) - H
        for (int i =0;i< infix.length;i++){
            String current = infix[i];
            if (!isOper(current) && !isBracket(current)) {//不是符号和括号,只有数字,就把数字添加到stack里面
                postfix[index++] = current;
            }else if (isBracket(current)){
                if (current.equals("(")){
                    stack.push(current);
                }else if (current.equals(")")){
                    while (!isBracket(stack.peak())){
                        postfix[index++] = stack.pop();
                    }
                    stack.pop();
                }
            }else if (isOper(current)){
                if (stack.isEmpty()){
                    stack.push(current);
                }else if (isBracket(stack.peak())){
                    stack.push(current);
                }else if (Oper_Map.get(stack.peak()) >= Oper_Map.get(current)){
                    postfix[index++] = stack.pop();
                    stack.push(current);
                }else if (Oper_Map.get(stack.peak()) < Oper_Map.get(current)){
                    stack.push(current);
                }
            }
        }
        while (!stack.isEmpty()){
            postfix[index++] = stack.pop();
        }
        return postfix;
    }

    public static boolean isBracket(String s){
        return s.equals("(") || s.equals(")");
    }


    public String getInfix(String[] exp) {
        ArrayStack s = new ArrayStack(exp.length);

        for (int i = 0; i < exp.length; i++) {
            String current = exp[i];
            if (!isOper(current)) {
                s.push(current + "");
            } else {
                String op1 = s.peak();
                s.pop();
                String op2 = s.peak();
                s.pop();
                s.push("(" + op2 +current +
                        op1 + ")");
            }
        }
        return s.peak();
    }

    public static double todouble(String str) {
        double num;
        num = Double.parseDouble(str);
        return num;
    }

    public static boolean isOper(String val) {
        return "+".equals(val) || "-".equals(val) || "*".equals(val) || "/".equals(val);
    }

    public static int getBrace(String[] strings){
        int num = 0;
        for (String ss : strings){
            if (ss.equals("(") || ss.equals(")")){
                num++;
            }
        }
        return num;
    }
}

