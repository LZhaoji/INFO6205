package INFO6205.assignment4;


import INFO6205.assignment23.People_Array;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class People_arrray {
    private int id;
    private String firstName;
    private String lastName;
    private String Course;

    public People_arrray() {
    }

    public People_arrray(int id, String firstName, String lastName, String course) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        Course = course;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCourse() {
        return Course;
    }

    public void setCourse(String course) {
        Course = course;
    }

    @Override
    public String toString() {
        return "People_Array{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", Course='" + Course + '\'' +
                '}';
    }

    //创建csv文件，进行写读操作
    public static List<String> FileUtil() throws IOException {
        People_arrray p1 = new People_arrray(1, "Jack", "Irwan", "Software Engineering");
        People_arrray p2 = new People_arrray(2, "Billy", "Mckao", "Requirement Engineering");
        People_arrray p3 = new People_arrray(3, "Nat", "Mcfaden", "Multivariate Calculus");
        People_arrray p4 = new People_arrray(4, "Steven", "Shwimmer", "Software Engineering");
        People_arrray p5 = new People_arrray(5, "Ruby", "Jason", "Relational DBMS");
        People_arrray p6 = new People_arrray(6, "Mark", "Dyne", "PHP development");
        People_arrray p7 = new People_arrray(7, "Philip", "Namdaf", "Microsoft Dot Net Platform");
        People_arrray p8 = new People_arrray(8, "Erik", "Bawn", "HTMI&Scripting");
        People_arrray p9 = new People_arrray(9, "Ricky", "Ben", "Data communication");
        People_arrray p10 = new People_arrray(10, "Van", "Miecky", "Computer Networks");

        BufferedWriter bw = new BufferedWriter(new FileWriter("/input2.txt"));
        List<People_arrray> peopleList = new ArrayList<>();
        peopleList.add(p1);
        peopleList.add(p2);
        peopleList.add(p3);
        peopleList.add(p4);
        peopleList.add(p5);
        peopleList.add(p6);
        peopleList.add(p7);
        peopleList.add(p8);
        peopleList.add(p9);
        peopleList.add(p10);
        for (People_arrray people : peopleList) {
            bw.write(people.getId() + "," + people.getFirstName() + "," + people.getLastName() + "," + people.getCourse());
            bw.newLine();
            bw.flush();
        }
        bw.close();

        BufferedReader br = new BufferedReader(new FileReader("/input2.txt"));
        String peopleTXT = null;
        List<String> peopleData = new ArrayList<>();
        while ((peopleTXT = br.readLine()) != null) {
            peopleData.add(peopleTXT);
        }
        br.close();
        return peopleData;
    }
    //split csv文件，得到People的ArrayList
    public List<People_arrray> splitString() throws IOException {
        List<String> strings = People_arrray.FileUtil();
        List<People_arrray> Pinfors = new ArrayList<>();

        for (String infor : strings) {
            String[] s = infor.split(",");
            int id = Integer.parseInt(s[0]);
            People_arrray pinfor = new People_arrray();
            pinfor.setId(id);
            pinfor.setFirstName(s[1]);
            pinfor.setLastName(s[2]);
            pinfor.setCourse(s[3]);
            Pinfors.add(pinfor);
        }
        return Pinfors;
    }

    private class Queue_Array{
        int rear;
        int front;
        int maximum_size;
        int current_size;
        Object[] arr;

        public Queue_Array(){}
        public Queue_Array(int size){
            rear = -1;//
            front = 0;
            current_size = 0;
            maximum_size = size;
            arr = new Object[size];
        }
        public int size(){return current_size;}
        public boolean isFull(){return size() == maximum_size;}
        public boolean isEmpty(){return size() == 0;}
        public void enqueue(Object item){

            rear = (rear + 1) % maximum_size;//
            arr[rear] = item;//
            current_size++;
        }
        public Object dequeue(){
            if (isEmpty()){
                System.out.println("stack is empty");
                System.exit(1);
            }
            Object item = arr[front];
            front = (front + 1) % maximum_size;
            current_size--;
            return item;
        }
        public Object peek(){
            return arr[rear];
        }//
    }

    public void demo() throws IOException {
        People_arrray function = new People_arrray();
        List<People_arrray> peopleList = function.splitString();
        System.out.println("\noriginal order for array stack:");
        for (People_arrray people : peopleList) {
            System.out.println(people);
        }
        Queue_Array queue_array = new Queue_Array(peopleList.size());
        System.out.println("enqueue all elements into queue");
        for (int i = peopleList.size()-1;i>=0;i--){
            queue_array.enqueue(peopleList.get(i));
        }


        System.out.println("\ndequeue 4 elements from queue");
        for (int i = 0; i < 4; i++) {
            System.out.println(queue_array.dequeue());
        }


        System.out.println("\nenqueue all elements into queue");
        for (int i = peopleList.size()-1;i>=0;i--){
            queue_array.enqueue(peopleList.get(i));
        }
        System.out.println("\ndequeue all elements from queue");
        for (int i = 0; i < peopleList.size(); i++) {
            System.out.println(queue_array.dequeue());
        }

        System.out.println("\ndequeue 2 element");
        for (int i = 0; i < 2; i++) {
            System.out.println(queue_array.dequeue());
        }

        System.out.println("\nenqueue all elements into queue");
        for (int i = peopleList.size()-1;i>=0;i--){
            queue_array.enqueue(peopleList.get(i));
        }

        People_arrray p11 = new People_arrray(11, "john", "henry", "software development");
        People_arrray p12 = new People_arrray(12, "Raj", "Manish", "Statistician");
        People_arrray p13 = new People_arrray(13, "Justin", "Morgan", "engineering statistics");
        peopleList.add(p11);
        peopleList.add(p12);
        peopleList.add(p13);
        Queue_Array queue_array_new = new Queue_Array(peopleList.size());
        for (int i = peopleList.size()-1;i>=0;i--){
            queue_array_new.enqueue(peopleList.get(i));
        }
    }
}
