package INFO6205.assignment4;

public class Hanoi {
    /*
    for hanoi problem, the data structure should be the stack
    the reason is the top plant is the last one pushed into the hanoi and the bottle one has to wait the all plant
    above it are moved first and then can be popped from the hanoi

    for 3-disk hanoi:
    Step 1 : Shift first disk from 'A' to 'C'.
    Step 2 : Shift second disk from 'A' to 'B'.
    Step 3 : Shift first disk from 'C' to 'B'.
    Step 4 : Shift third disk from 'A' to 'C'.
    Step 5 : Shift first disk from 'B' to 'A'.
    Step 6 : Shift second disk from 'B' to 'C'.
    Step 7 : Shift first disk from 'A' to 'C'.

    it seems like that n-1 disk from 'A' pass by 'C' then to 'B'
    then the nth disk from 'A' to 'C'
    finally move n-1 disks from 'B' pass by 'A' then to 'C'

    time complexity: move n-1 disk from A to B need n-1 steps
                     move nth disk from A to C need one-step
                     move n-1 disk from B to C need n-1 steps
                     T(n) = 2*T(n-1)+1 for n-disk need T(n) steps
                     so the time complexity is 2^n
     */

    public static void hanoi(int n,char A_col,char B_col,char C_col){
        if (n >= 1) {
            hanoi(n - 1, A_col, C_col, B_col);
            System.out.println("move disk" + n + " from " + A_col + " to " + C_col);
            hanoi(n - 1, B_col,A_col,C_col);
        }
    }

    public static void main(String[] args) {
        hanoi(3,'A','B','C');
    }

    /*
    move disk1 from A to C
    move disk2 from A to B
    move disk1 from C to B
    move disk3 from A to C
    move disk1 from B to A
    move disk2 from B to C
    move disk1 from A to C
     */
}
